	        </div>
	        <!-- /.row -->
	    </div>
	    <!-- /.container-fluid -->
	</div>
	</div>

	<script src="vendor/tinymce/tinymce.min.js"></script>
	<script type="text/javascript" src="vendor/Persian-Jalali/src/kamadatepicker.min.js"></script>
	<script type="text/javascript" src="vendor/mousewheel/jquery.mousewheel.js"></script>
	    
	<script>tinymce.int({ selector:'textarea' });</script>

	<script type="text/javascript" src="themes/2020/js/scripts.js"></script>

  </body>
</html>