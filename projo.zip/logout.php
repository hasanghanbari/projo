<?php 
setcookie("projo"," ",time()-860000);
header('location: ./');

 ?>