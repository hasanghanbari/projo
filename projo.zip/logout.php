<?php 
setcookie("iproject"," ",time()-860000);
header('location: ./');

 ?>